﻿
using System;
using System.Collections.Generic;

namespace RideSharingSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            RideSharingService rideSharingService = new RideSharingService();
            rideSharingService.Start();
        }
    }

    public class RideSharingService
    {
        private List<User> users = new List<User>();
        private List<Driver> drivers = new List<Driver>();
        private List<Ride> rides = new List<Ride>();

        public void Start()
        {
            while (true)
            {
                Console.WriteLine("1. Register as Rider");
                Console.WriteLine("2. Register as Driver");
                Console.WriteLine("3. Request a Ride");
                Console.WriteLine("4. Accept a Ride");
                Console.WriteLine("5. Complete a Trip");
                Console.WriteLine("6. View Ride History");
                Console.WriteLine("7. View Trip History");
                Console.WriteLine("8. Display All Trips");
                Console.WriteLine("9. Exit");
                Console.Write("Select an option: ");
                var choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        RegisterRider();
                        break;
                    case "2":
                        RegisterDriver();
                        break;
                    case "3":
                        RequestRide();
                        break;
                    case "4":
                        AcceptRide();
                        break;
                    case "5":
                        CompleteTrip();
                        break;
                    case "6":
                        ViewRideHistory();
                        break;
                    case "7":
                        ViewTripHistory();
                        break;
                    case "8":
                        DisplayAllTrips();
                        break;
                    case "9":
                        return;
                    default:
                        Console.WriteLine("Sorry! Invalid choice...");
                        break;
                }
            }
        }

        private void RegisterRider()
        {
            Console.Write("Enter User Name: ");
            string name = Console.ReadLine();
            users.Add(new User(name));
            Console.WriteLine("Rider registered successfully.");
        }

        private void RegisterDriver()
        {
            Console.Write("Enter Driver Name: ");
            string name = Console.ReadLine();
            drivers.Add(new Driver(name));
            Console.WriteLine("Driver registered successfully.");
        }

        private void RequestRide()
        {
            Console.Write("Enter Your Name: ");
            string userName = Console.ReadLine();
            Console.Write("Enter Your Current Location: ");
            string currentLocation = Console.ReadLine();
            Console.Write("Enter Your Destination: ");
            string destination = Console.ReadLine();

            rides.Add(new Ride(userName, destination));
            Console.WriteLine("Ride requested successfully.");
        }

        private void AcceptRide()
        {
            Console.Write("Enter Driver Name: ");
            string driverName = Console.ReadLine();
            Console.Write("Enter Ride ID to accept: ");
            int rideId = int.Parse(Console.ReadLine());

            if (rideId < rides.Count)
            {
                rides[rideId].AcceptRide(driverName);
                Console.WriteLine("Ride accepted successfully.");
            }
            else
            {
                Console.WriteLine("Invalid Ride ID.");
            }
        }

        private void ViewTripHistory()
        {
            Console.WriteLine("Trip History:");
            foreach (var ride in rides)
            {
                Console.WriteLine(ride.ToString());
            }
        }

        private void CompleteTrip()
        {
            Console.Write("Enter Ride ID to complete: ");
            int rideId = int.Parse(Console.ReadLine());

            if (rideId < rides.Count)
            {
                Console.WriteLine($"Trip to {rides[rideId].Destination} has been completed.");
                rides.RemoveAt(rideId);
            }
            else
            {
                Console.WriteLine("Invalid Ride ID.");
            }
        }

        private void ViewRideHistory()
        {
            Console.WriteLine("Ride History:");
            foreach (var ride in rides)
            {
                Console.WriteLine(ride.ToString());
            }
        }

        private void DisplayAllTrips()
        {
            Console.WriteLine("All Trip History:");
            foreach (var ride in rides)
            {
                Console.WriteLine(ride.ToString());
            }
        }
    }

    public class User
    {
        public string Name { get; private set; }

        public User(string name)
        {
            Name = name;
        }
    }

    public class Driver
    {
        public string Name { get; private set; }

        public Driver(string name)
        {
            Name = name;
        }
    }

    public class Ride
    {
        public string UserName { get; private set; }
        public string Destination { get; private set; }
        public string DriverName { get; private set; }
        public bool IsAccepted { get; private set; }

        public Ride(string userName, string destination)
        {
            UserName = userName;
            Destination = destination;
            IsAccepted = false;
        }

        public void AcceptRide(string driverName)
        {
            DriverName = driverName;
            IsAccepted = true;
        }

        public override string ToString()
        {
            return $"User: {UserName}, Destination: {Destination}, Driver: {DriverName ?? "Not Assigned"}, Accepted: {IsAccepted}";
        }
    }
}
